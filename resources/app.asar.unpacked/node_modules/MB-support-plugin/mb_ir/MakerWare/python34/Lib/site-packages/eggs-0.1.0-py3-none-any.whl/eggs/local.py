import time
import asyncio
import json

@asyncio.coroutine
def get_local_bots(detectors, timeout=1, delay=1):
    start_time = time.time()
    bots = {}
    
    try:
        while True:
            yield from asyncio.sleep(delay)
            for detector in detectors:
                for bot in [bot for bot in detector.foundBots if bot not in bots]:
                    print(json.dumps(detector.foundBots[bot], sort_keys=True))
                    bots[bot] = detector.foundBots[bot]

            if timeout and start_time + timeout < time.time():
                break
    finally:
        for detector in detectors:
            detector.shut_it_down()
