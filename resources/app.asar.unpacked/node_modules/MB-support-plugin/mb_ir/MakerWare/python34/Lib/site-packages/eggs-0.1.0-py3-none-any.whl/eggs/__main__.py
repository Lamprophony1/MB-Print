import asyncio
import json
import argparse
import sys
import os
import time

from . import auth
from . import local
from . import reflector
from . import detector_usb
from . import detector_old
from . import detector_mdns

from asyncio.streams import StreamWriter, FlowControlMixin
reader, writer = None, None
tasks = {}

reflector_api = 'https://reflector.makerbot.com'


@asyncio.coroutine
def stdio(loop=None):
    if loop is None:
        loop = asyncio.get_event_loop()

    reader = asyncio.StreamReader()
    reader_protocol = asyncio.StreamReaderProtocol(reader)

    writer_transport, writer_protocol = yield from loop.connect_write_pipe(FlowControlMixin, sys.stdin)
    writer = StreamWriter(writer_transport, writer_protocol, None, loop)

    yield from loop.connect_read_pipe(lambda: reader_protocol, sys.stdin)

    return reader, writer

def get_local_bots(timeout=1, delay=1, thingiverse_token=None):
    lan_mdns_detector = detector_mdns.MakerBotDetector()
    lan_old_detector = detector_old.MakerBotDetector()
    usb_detector = detector_usb.MakerBotDetector()

    return local.get_local_bots([lan_mdns_detector, lan_old_detector, usb_detector], timeout=timeout, delay=delay)

def get_reflector_bots(thingiverse_token):
    yield from reflector.get_reflector_bots(reflector_api, thingiverse_token)

def get_local_auth(machine_ip, client_secret, username, thingiverse_token, timeout=120, birdwing_code=None):
    yield from auth.get_auth_tokens(machine_ip, client_secret, username, thingiverse_token, timeout, birdwing_code=birdwing_code)

def get_reflector_auth(thingiverse_token, printer_iserial):
    reflector_call = yield from reflector.do_reflector_call(reflector_api, thingiverse_token, printer_iserial)

@asyncio.coroutine
def stop(task):
    try:
        tasks[task].cancel()
    except:
        print(json.dumps({"command": "stop", "task": task, "status": "error"}))
        return
    finally:
        try:
            del tasks[task]
        except:
            pass
    del(tasks["stop"])
    print(json.dumps({"command": "stop", "task": task, "status": "done"}))


def parse_input(message):
    if len(message) < 2:
        return None, None

    message = json.loads(message)
    command = message["command"]
    args = message["args"]
    return command, args

@asyncio.coroutine
def main():

    global reader, writer
    reader, writer = yield from stdio()

    while True:
        yield from asyncio.sleep(.1)

        try:
            line = yield from reader.readline()
            line = line.decode()
        except Exception as e:
            print(e)
            continue

        command, args = parse_input(line)

        possibles = globals().copy()
        possibles.update(locals())
        method = possibles.get(command)

        tasks[command] = asyncio.async(method(**args))


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='')
    parser.add_argument(
        'command',
        metavar='COMMAND',
        type=str,
        nargs='?',
        help='')

    parser.add_argument(
        '-r', '--repl',
        dest='repl',
        action='store_true')

    parser.add_argument(
        '-i', '--machine_ip',
        metavar='IP_ADDR',
        type=str,
        dest='machine_ip',
        nargs='?',
        help='IP Address of the printer.')

    parser.add_argument(
        '-s', '--client_secret',
        metavar='CLIENT_SECRET',
        type=str,
        dest='client_secret',
        nargs='?',
        help='Client secret code.')

    parser.add_argument(
        '-u', '--username',
        metavar='USERNAME',
        type=str, dest='username',
        nargs='?',
        help='Username of the user connecting.')

    parser.add_argument(
        '-k', '--thingiverse_token',
        metavar='THINGIVERSE_TOKEN',
        type=str,
        dest='thingiverse_token',
        default=None,
        nargs='?',
        help='User\'s Thingiverse token')

    parser.add_argument(
        '-t', '--timeout',
        metavar='TIMEOUT_SECONDS',
        type=int,
        dest='timeout',
        default=120,
        nargs='?',
        help='Optional authentication timeout in seconds.')

    parser.add_argument(
        '-d', '--delay',
        metavar='DELAY',
        type=int,
        dest='delay',
        default=1,
        nargs='?',
        help='Delay between returned dicts of detected bots.')

    parser.add_argument(
        '-b', '--birdwing_code',
        metavar='BIRDWING_CODE',
        type=str,
        dest='birdwing_code',
        default=None,
        nargs='?',
        help='Saved Birdwing Code, to get one-time-token if you\'ve already authed to a bot')

    parser.add_argument(
        '-p', '--printer_iserial',
        metavar='PRINTER_ISERIAL',
        type=str,
        dest='printer_iserial',
        nargs='?',
        help='Printer iserial.')

    args = parser.parse_args()

    if args.repl:
        asyncio.get_event_loop().run_until_complete(main())
    else:
        loop = asyncio.get_event_loop()

        if args.command == 'get_local_bots':
            loop.run_until_complete(get_local_bots(args.timeout, args.delay, args.thingiverse_token))

        elif args.command == 'get_reflector_bots':
            loop.run_until_complete(get_reflector_bots(args.thingiverse_token))

        elif args.command == 'get_local_auth':
            loop.run_until_complete(get_local_auth(
                args.machine_ip,
                args.client_secret,
                args.username,
                args.thingiverse_token,
                args.timeout,
                args.birdwing_code))

        elif args.command == 'get_reflector_auth':
            loop.run_until_complete(get_reflector_auth(args.thingiverse_token, args.printer_iserial))
        loop.close()
