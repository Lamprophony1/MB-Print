from . import PrintStream
import makerbot_driver
from . import StreamingExceptions
import struct

DEBUG = True

class X3GStream(PrintStream.PrintStream):
	def __init__(self, streaming_config, requested_file, access_token, printer_type):
		super(X3GStream, self).__init__(streaming_config, requested_file, access_token, printer_type)

	from .CommandLists import X3GCOMMANDS, X3GConstants
	commands = X3GCOMMANDS

	def parse_command(self):
		command_byte = self[self.index]
		command_length = self.commands[command_byte][2]

		if DEBUG and self.commands[command_byte][1] is None:
			raise StreamingExceptions.UnknownCommandError("Unrecognized command: %d" % command_byte)
		
		if command_length == self.X3GConstants.kToolActionLength:
			# 3 byte offset -- first three bytes are toolid, action command,
			# length of tool command
			tool_command_length = self[self.index + 3]
			command_length = 3 + tool_command_length

		elif command_length == self.X3GConstants.DisplayToLCDLength:
			build_name_end = self.find_next(0, start_index=self.index + 5)
			command_length = build_name_end - self.index

		# Increment command length to account for command byte
		command_length += 1
		payload = self[self.index : self.index + command_length]
		self.index += command_length

		if self.index >= len(self.reading_buffer):
			try:
				self.swap_buffers()
			except StreamingExceptions.LatePacket:
				raise

		if DEBUG:
			if len(payload) != command_length:
				raise StreamingExceptions.WrongPayloadLengthError("Expected command length to be %d (was %d) for command %s." % (command_length, len(payload), payload))

		return payload

	def resume(self):
		"""
		resume the machine
		"""
		self._suspended = False
		return struct.pack(
					'<B',
					makerbot_driver.host_query_command_dict['PAUSE'],
		)

	def suspend(self):
		"""
		pause the machine
		"""
		self._suspended = True
		return struct.pack(
			'<B',
			makerbot_driver.host_query_command_dict['PAUSE'],
		)