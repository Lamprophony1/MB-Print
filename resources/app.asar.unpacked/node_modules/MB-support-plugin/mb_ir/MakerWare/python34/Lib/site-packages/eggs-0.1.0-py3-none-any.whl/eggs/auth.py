import aiohttp
import asyncio
import json
import ssl
import time

from . import jsonrpc
from . import jsonrpc_connection


class AuthRejectedException(Exception):
    """
    Indicates that a user explicitly denied a printer UI auth attempt

    Should only be raised when a user physically present at the bot opts
    to reject an authorization attempt.  Reauthorization attempts cannot
    be rejected this way.
    """
    pass


class AuthTimedOutException(Exception):
    """
    Indicates that a printer UI auth attempt timed out

    Raised if no user physically present at the bot takes any action to
    accept or reject a UI auth attempt within a certain amount of time.
    The amount of time allowed is determined by the bot.  Reauthorization
    attempts cannot time out this way.
    """
    pass


class UnauthorizedException(Exception):
    """
    Indicates that reauthorization credentials were explicitly rejected.

    Should only be raised when the bot explicitly indicates that the local
    code or the thingiverse token passed are unauthorized, and that the
    client will have to call authorize in order to connect.
    """
    pass


class AuthNoCloudException(Exception):
    """
    Indicates that reauthorization failed due to internet connection issues

    Under certain circumstances, reauthorization with a makerbot account
    can require a connection from the bot to makerbot cloud servers.  If
    that connection attempt fails, this error gets raised.  Reauth attempts
    with only a local code should not fail this way.
    """
    pass


class Timeout:
    # TODO: Is time.time() actually monotonic?
    def __init__(self, timeout):
        """ Specify a time in seconds, or None to never timeout """
        self._timeout = timeout
        if self._timeout is not None:
            self._start = time.time()

    def check(self):
        """ Return True if we did not time out """
        if self._timeout is None:
            return True
        return (time.time() - self._start) < self._timeout


class FCGIAuthenticator:
    def __init__(self, ip, client_secret):
        self._ip = ip
        self._common_path_kwargs = {
            'client_id': 'MakerWare',
            'client_secret': client_secret,
        }
        self._user_info = {}
        self._stdout_cmd_name = None

    def set_user_info(self, username=None, thingiverse_token=None):
        if username is not None:
            self._user_info['username'] = username
        if thingiverse_token is not None:
            self._user_info['thingiverse_token'] = thingiverse_token

    def enable_stdout(self, command_name):
        """ Enable the printing of json dicts to stdout """
        self._stdout_cmd_name = command_name

    def _update_status(self, **kwargs):
        if self._stdout_cmd_name is not None:
            kwargs.update({
                "command": self._stdout_cmd_name,
                "machine_ip": self._ip,
            })
            print(json.dumps(kwargs))

    def _do_get(self, path):
        url = "https://%s%s" % (self._ip, path)
        conn = aiohttp.TCPConnector(verify_ssl=False)
        response = yield from aiohttp.request('GET', url, connector=conn)
        output = yield from response.read()
        conn.close()
        return output

    def _do_json_get(self, path):
        response_bytes = yield from self._do_get(path)
        return json.loads(response_bytes.decode('ascii'))

    def _get_remote_path(self, response_type, **kwargs):
        remoteargs = ["/auth?response_type=%s" % response_type]
        kwargs.update(self._common_path_kwargs)
        for key in kwargs:
            remoteargs.append(key + '=' + kwargs[key])
        remotepath = '&'.join(remoteargs)
        return remotepath

    @asyncio.coroutine
    def _get_answer_code(self):
        path = self._get_remote_path("code", **self._user_info)
        answer = yield from self._do_json_get(path)
        answer_code = answer["answer_code"]
        return answer_code

    @asyncio.coroutine
    def _loop_for_birdwing_code(self, answer_code, timeout=None):
        path = self._get_remote_path("answer", answer_code=answer_code)
        timeout_checker = Timeout(timeout)
        while timeout_checker.check():
            response = yield from self._do_json_get(path)
            answer = response.get('answer')
            if answer == "accepted":
                return response["code"]
            elif answer == "rejected":
                raise AuthRejectedException()
            elif answer == "timedout":
                raise AuthTimedOutException()
            elif answer != "pending":
                raise Exception("Bad response %r" % response)
            self._update_status(status=answer)

    @asyncio.coroutine
    def _get_auth_token(self, birdwing_code):
        path = self._get_remote_path("token", context="jsonrpc",
                                     auth_code=birdwing_code)
        answer = yield from self._do_json_get(path)
        if "access_token" not in answer:
            raise UnauthorizedException()
        return answer["access_token"]

    @asyncio.coroutine
    def get_auth_tokens(self, timeout=None, birdwing_code=None):
        if birdwing_code is None:
            answer_code = yield from self._get_answer_code()
            loop_coro = self._loop_for_birdwing_code(answer_code, timeout)
            birdwing_code = yield from loop_coro
        auth_token = yield from self._get_auth_token(birdwing_code)
        self._update_status(status="ok", birdwing_code=birdwing_code,
                            auth_token=auth_token)
        return (auth_token, birdwing_code)


@asyncio.coroutine
def get_auth_tokens(machine_ip, client_secret, username, thingiverse_token,
                    timeout=None, birdwing_code=None, do_stdout=True):
    try:
        auther = FCGIAuthenticator(machine_ip, client_secret)
        auther.set_user_info(username, thingiverse_token)
        if do_stdout:
            auther.enable_stdout('get_auth_tokens')
        res = yield from auther.get_auth_tokens(timeout, birdwing_code)
        return res
    except Exception as e:
        import traceback
        traceback.print_exc()


class SSLAuthenticator(jsonrpc_connection.JsonRpcConnection):
    """
    Context manager to perform ssl jsonrpc auth

    Wraps a jsonrpc object in the necessary logic to connect to kaiten
    over ssl, and provides convenience methods to use the kaiten auth
    API.  The context manager ensures that we clean up when we are done
    and also converts known jsonrpc error codes into custom exception
    classes.
    """
    def __init__(self, ip, port, username):
        super(SSLAuthenticator, self).__init__(ip, port)
        self._username = username

    def __exit__(self, type, value, traceback):
        # First clean up
        self._jsonrpc.close()

        # Now map known jsonrpc exceptions to auth errors
        if not isinstance(value, jsonrpc.JsonRpcException):
            return False
        elif value.code == 25:  # authorization rejected
            raise AuthRejectedException()
        elif value.code == 26:  # authorization timed out
            raise AuthTimedOutException()
        elif value.code == 27:  # invalid credentials
            raise UnauthorizedException()
        elif value.code == 29:  # auth_server_unreachable
            raise AuthNoCloudException()
        else:
            return False

    @asyncio.coroutine
    def _connect(self):
        # Create an ssl context that does not verify the ssl certificate
        ssl_cxt = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
        yield from super(SSLAuthenticator, self)._connect(ssl_cxt)

    @asyncio.coroutine
    def authorize(self, makerbot_token=None, local_secret=None):
        params = {
            'username': self._username,
            'makerbot_token': makerbot_token,
            'local_secret': local_secret,
        }
        return (yield from self._request('authorize', params))

    @asyncio.coroutine
    def reauthorize(self, makerbot_token=None,
                    local_secret=None, local_code=None):
        params = {
            'username': self._username,
            'makerbot_token': makerbot_token,
            'local_secret': local_secret,
            'local_code': local_code,
        }
        return (yield from self._request('reauthorize', params))


# Croissant auth API:
#
# All auth API functions will use the new ssl jsonrpc kaiten auth API
# if ssl_port is passed, otherwise they will do their best to provide
# the same auth behavior using the old fcgi rest api.
#
# A machine IP address and a username are required for all functions.
# Note that croissant will explicitly pass None for optional arguments
# that it does not want to specify.


@asyncio.coroutine
def croissant_auth(machine_ip, username, ssl_port=None, client_secret=None,
                   thingiverse_token=None):
    """
    For first time authentication only

    Requires at least one of thingiverse_token or client_secret to be set.
    Should always prompt for a button press to authorize the user (except
    when using a known thingiverse token and fgci auth).

    Returns a (one_time_token, birdwing_code) tuple, though birdwing_code
    should be ignored if client_secret was not specified.
    """
    if client_secret is None and thingiverse_token is None:
        raise Exception('thingiverse_token or client_secret must be set')
    if ssl_port is not None:
        with SSLAuthenticator(machine_ip, ssl_port, username) as auther:
            res = yield from auther.authorize(thingiverse_token, client_secret)
        if client_secret is None:
            birdwing_code = ''
        else:
            birdwing_code = res['local_code']
        return (res['one_time_token'], birdwing_code)
    else:
        if client_secret is None:
            # With fcgi we still have to also do local auth
            client_secret = thingiverse_token
        auther = FCGIAuthenticator(machine_ip, client_secret)
        auther.set_user_info(username, thingiverse_token)
        res = yield from auther.get_auth_tokens(None, None)
        return res


@asyncio.coroutine
def croissant_reauth(machine_ip, username, ssl_port=None, client_secret=None,
                     thingiverse_token=None, birdwing_code=None):
    """
    For repeat authentication only

    Requires thingiverse_token or both client_secret and birding_code
    to be set.  Should never prompt for a button press to authorize the
    user (except when using an unknown thingiverse token and fgci auth).

    Returns a one_time_token
    """
    if client_secret is None and thingiverse_token is None:
        raise Exception('thingiverse_token or client_secret must be set')
    if client_secret is not None and birdwing_code is None:
        raise Exception('client_secret reauth requires birdwing_code')
    if ssl_port is not None:
        with SSLAuthenticator(machine_ip, ssl_port, username) as auther:
            res = yield from auther.reauthorize(
                thingiverse_token, client_secret, birdwing_code)
        return res['one_time_token']
    else:
        if client_secret is None:
            # With fcgi we still have to also do local auth
            client_secret = thingiverse_token
            birdwing_code = None
        auther = FCGIAuthenticator(machine_ip, client_secret)
        auther.set_user_info(username, thingiverse_token)
        res = yield from auther.get_auth_tokens(None, birdwing_code)
        return res[0]
