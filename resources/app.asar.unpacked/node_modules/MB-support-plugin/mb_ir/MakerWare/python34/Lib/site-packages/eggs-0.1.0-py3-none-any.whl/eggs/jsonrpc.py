import asyncio
import contextlib
import errno
import json
import logging
import io
import os
import socket
import sys
import types

from . import json_reader


def jsonrpc(func):
    func._jsonrpc = True
    immediate = getattr(func, '_jsonrpc_immediate', False)
    if immediate or asyncio.iscoroutinefunction(func):
        return func
    else:
        return asyncio.coroutine(func)


def immediate(func):
    if getattr(func, '_jsonrpc', False):
        raise RuntimeError('@jsonrpc.immediate must be below @jsonrpc.jsonrpc')
    elif asyncio.iscoroutinefunction(func):
        raise RuntimeError('@jsonrpc.immediate cannot handle coroutines')
    func._jsonrpc_immediate = True
    return func


def pass_callback(func):
    func._jsonrpc_callback = True
    return func


def pass_client(func):
    func._jsonrpc_client = True
    return func


def install(jsonrpc, obj):
    """
    Installs all callable components of obj that have been decorated with
    this module.  We have intentionally avoided inspect here
    for performance reasons.

    We allow both normal functions and generator functions, though some
    modifier decorators (pass_callback, jsonrpc_immediate) do not
    support generators and will raise a runtime error when a generator
    they decorate is invoked.
    """
    for attribute_name in dir(obj):
        attr = getattr(obj, attribute_name)
        # If it quacks like a function...
        if hasattr(attr, '__call__') and getattr(attr, '_jsonrpc', False):
            exported_name = attribute_name
            jsonrpc.addmethod(attribute_name, attr)


class JsonRpcException(Exception):
    def __init__(self, code, message, data=None):
        Exception.__init__(self, code, message)
        self.code = code
        self.message = message
        self.data = data

    def __str__(self):
        return ("Code: %s, Message: %s, Data: %s" %
                (self.code, self.message, self.data))


def exc_to_error(e):
    """
    When running a pass_callback method and a JsonRpcException e is raised,
    call callback(error=jsonrpc.exc_to_error(e))
    """
    error = {'code': e.code, 'message': e.message}
    if None is not e.data:
        error['data'] = e.data
    return error


class JsonRpc:
    """
    Implements jsonrpc 2.0 over asyncio streams

    Provides request and notification coroutine methods to invoke api
    methods on the remote end, and an addmethod method to register
    api methods that the remote end can invoke.

    This also ostenisbly implements a non-standard jsonrpc "raw mode"
    extension, though this is completely untested in this version of
    our jsonrpc module.
    """
    def __init__(self, reader, writer):
        """
        @param reader: Any asyncio.StreamReader interface
        @param writer: Any asyncio.StreamWriter interface
        """
        self._log = logging.getLogger('JsonRpc')
        self._reader = reader
        self._writer = writer
        self._jsonreader = json_reader.JsonReader(self._jsonreaderresp, False)
        self._methods = {}
        self._jobs = {}
        self._id_counter = 0
        self._raw_handler = None
        asyncio.async(self._run())

    #
    # Common part
    #

    def _get_id(self):
        new_id = self._id_counter
        self._id_counter += 1
        return new_id

    def _jsonreaderresp(self, indata):
        """
        Fired off when a complete jsonrpc packet is parsed by the json reader
        """
        try:
            parsed = json.loads(indata)
        except ValueError:
            response = self._parse_error()
        else:
            if isinstance(parsed, dict):
                # This is checked here and not in handle_object, since arrays
                # are not supposed to have responses in them and we DONT want
                # to support that.
                if self._is_response(parsed):
                    self._handle_response(parsed)
                    # We return here, since theres no more work to be done
                    return
                else:
                    response = self._handle_object(parsed)
            else:
                response = self._invalid_request(None)
        if None is not response:
            outdata = json.dumps(response)
            self._async_send(outdata)

    def _handle_object(self, parsed):
        """
        Handles a parsed object.  Depending on the contents of the parsed dict,
        it will either invoke it as a notification or as a request.  Depending
        on the method, this will either directly execute the function or queue
        it for later execution.
        """
        # We check is parsed is a dict again here to support _handle_array
        if not isinstance(parsed, dict):
            return self._invalid_request(None)
        else:
            is_request = self._is_request(parsed)
            is_notification = self._is_notification(parsed)
            if is_request or is_notification:
                method = parsed["method"]
                if method in self._methods:
                    func = self._methods[method]
                    if is_request:
                        self._handle_request(parsed)
                    else:
                        self._handle_notification(parsed)
                elif is_request:
                    return self._method_not_found(parsed.get("id"))
            else:
                return self._invalid_request(parsed.get("id"))

    def _handle_response(self, parsed):
        """
        Resolve any self._jobs futures waiting on a response

        The future will be resolved with the result of the call or a
        JsonRpcException for any error response.

        We mostly assume the parsed blob is correctly formatted, but we
        do check here for a correctly formatted error packet.
        """
        if parsed['id'] in self._jobs:
            job = self._jobs.pop(parsed['id'])
            response_blob = {}
            if 'error' in parsed:
                error_packet = parsed['error']
                try:
                    error = JsonRpcException(**error_packet)
                except TypeError:
                    error = JsonRpcException(
                        -31999, "Invalid error response", error_packet)
                job.set_exception(error)
            else:
                job.set_result(parsed['result'])

    def _is_request(self, parsed):
        """
        Determines if this dict is a request.  Requests have an ID field, and
        are expected to return some sort of result.
        """
        return (
            'jsonrpc' in parsed
            and '2.0' == parsed['jsonrpc']
            and 'method' in parsed
            and isinstance(parsed['method'], str)
            and 'id' in parsed)

    def _is_notification(self, parsed):
        """
        Determines if this dict is a notification. Notifications are the same
        as requests, except that they do not have an 'ID' field
        """
        return (
            'jsonrpc' in parsed
            and '2.0' == parsed['jsonrpc']
            and 'method' in parsed
            and isinstance(parsed['method'], str)
            and 'id' not in parsed)

    def _is_response(self, parsed):
        """
        Determines if this dict is a response to a previously sent message.
        """
        return (self._is_success_response(parsed)
                or self._is_error_response(parsed))

    def _is_success_response(self, parsed):
        """
        Success responses have a result and no error, and the ID of the calling
        RPC
        """
        return (parsed.get('jsonrpc') == "2.0" and 'id' in parsed and
                'error' not in parsed and 'result' in parsed)

    def _is_error_response(self, parsed):
        """
        Error responses have an error and no result, and the ID of the calling
        RPC
        """
        return (parsed.get('jsonrpc') == "2.0" and 'id' in parsed and
                'error' in parsed and 'result' not in parsed)

    def _success_response(self, id, result):
        return {'jsonrpc': '2.0', 'result': result, 'id': id}

    def _errorresponse(self, id, code, message, data=None):
        error = {'code': code, 'message': message}
        if None is not data:
            error['data'] = data
        return {'jsonrpc': '2.0', 'error': error, 'id': id}

    def _parse_error(self):
        return self._errorresponse(None, -32700, 'parse error')

    def _invalid_request(self, id):
        return self._errorresponse(id, -32600, 'invalid request')

    def _method_not_found(self, id):
        return self._errorresponse(id, -32601, 'method not found')

    def _invalid_params(self, id):
        return self._errorresponse(id, -32602, 'invalid params')

    @asyncio.coroutine
    def _send(self, data, extra=None):
        """
        Send one complete json packet along with any associated raw bytes

        This internal function is invoked by multiple independent
        coroutines, so there is no guaranteed packet ordering.  This
        is a coroutine so that it can wait for the write queue to have
        room, but we never yield in the middle of a write to ensure that
        packets do not interrupt each other.
        """
        data = bytes(data, 'utf-8')
        if None is not extra:
            self._writer.writelines((data, extra))
        else:
            self._writer.write(data)

    def _async_send(self, data, extra=None):
        """
        Convenience function to run _send asynchronously
        """
        asyncio.async(self._send(data, extra))

    @asyncio.coroutine
    def _feed(self, data):
        """
        Feed a chunk of data to either to the main json parser or a custom raw
        data parser.  Every time the json parser yields we check if there is a
        custom parser; the custom parser is done as soon as it yields data.
        """
        while data:
            if None is self._raw_handler:
                for index in self._jsonreader.feed_iter(data):
                    yield
                    if None is not self._raw_handler:
                        data = data[index:]
                        break
                else:
                    return
            else:
                try:
                    data = self._raw_handler.send(data)
                    if data:
                        self._raw_handler.close()
                        self._raw_handler = None
                        yield
                except StopIteration:
                    self._raw_handler = None
                    return

    @asyncio.coroutine
    def _run(self):
        while True:
            data = yield from self._reader.read(4096)
            if not data:  # Indicates EOF
                break
            yield from self._feed(data)

    def close(self):
        try:
            self._writer.close()
            for job in self._jobs.values():
                job.cancel()
            self._jobs = {}
        except Exception as e:
            self._log.error('handled exception', exc_info=True)

    #
    # Client part
    #

    @asyncio.coroutine
    def notify(self, method, params, extra=None):
        """
        Sends a notification to a connected client.

        @param method: The method to be called on the client
        @param params: A dict of parameters (param arrays are discouraged)
        @param extra: This can contain an extra byte array which will be sent
            directly over the connection immediately after the notification.
        """
        request = {'jsonrpc': '2.0', 'method': method, 'params': params}
        data = json.dumps(request)
        yield from self._send(data, extra)

    @asyncio.coroutine
    def request(self, method, params, extra=None):
        """
        Sends a request to a connected client.

        @param method: The method to be called on the client
        @param params: A dict of parameters (param arrays are discouraged)
        @param extra: This can contain an extra byte array which will be sent
            directly over the connection immediately after the request.
        """
        _id = self._get_id()
        request = {'jsonrpc': '2.0', 'method': method,
                   'params': params, 'id': _id}
        data = json.dumps(request)
        self._jobs[_id] = future = asyncio.Future()
        yield from self._send(data, extra)
        return (yield from future)

    def set_raw_handler(self, generator):
        """
        Replace the json packet parser with a custom generator.  This can only
        be called safely when the other end of this connection is blocked from
        sending anything until it receives something from us.
        @param generator: This is fed the incoming data with .send().  Once it
            has received all of the data it needs, it must stop iteration.
            If it instead receives more data than it requires, it must yield
            back the extra data, at which point it will be closed.
        """
        self._raw_handler = generator
        next(self._raw_handler)

    #
    # Server part
    #

    def _get_args_kwargs(self, json_blob):
        """
        Gets the correct args and kwargs from the json_blob and returns them
        """
        if "params" not in json_blob:
            return ((), {})
        elif json_blob['params'] is None:
            return ((), {})
        elif isinstance(json_blob["params"], dict):
            params = json_blob["params"].copy()
            return ((), params)
        elif isinstance(json_blob["params"], list):
            return (json_blob["params"], {})
        else:
            raise AttributeError

    def _handle_notification(self, notification):
        """
        Processes a notification.  Assumes the packet is valid.
        Since its a notification, we catch all errors and do nothing
        with them.  We support generator methods, so this function is
        itself a generator.
        """
        method = notification['method']
        func = None

        @contextlib.contextmanager
        def guard():
            try:
                yield
            except Exception as e:
                self._log.error("Error executing notification %r",
                                notification, exc_info=True)
        with guard():
            (args, kwargs) = self._get_args_kwargs(notification)
            func = self._methods[method]
        if func:
            self._invoke_method(func, args, kwargs, guard)

    def _handle_request(self, request):
        """
        Handles a request.  Assumes the packet is valid and the method exists.
        Since its a request, we need to handle each error case and return an
        error packet.
        """
        _id = request["id"]
        method = request['method']
        try:
            (args, kwargs) = self._get_args_kwargs(request)
        except AttributeError as e:
            self._log.error('handled exception', exc_info=True)
            self._async_send(json.dumps(self._invalid_params(_id)))
        func = self._methods[method]

        @contextlib.contextmanager
        def guard():
            response = None
            try:
                yield
            except TypeError as e:
                self._log.error('handled exception: ' + str(e), exc_info=True)
                response = self._invalid_params(_id)
            except JsonRpcException as e:
                response = self._errorresponse(_id, e.code, e.message, e.data)
            except Exception as e:
                self._log.warning('uncaught exception', exc_info=True)
                e = sys.exc_info()[1]
                data = {'name': e.__class__.__name__, 'args': e.args}
                response = self._errorresponse(
                    _id, -32000, 'uncaught exception', data)
            if response:
                self._async_send(json.dumps(response))

        def callback(result):
            response = self._success_response(_id, result)
            self._async_send(json.dumps(response))

        if getattr(func, '_jsonrpc_callback', False):
            self._invoke_callback_method(_id, func, args, kwargs, guard)
        else:
            self._invoke_method(func, args, kwargs, guard, callback)

    def _fix_kwargs(self, kwargs):
        kwargs1 = {}
        for k, v in kwargs.items():
            k = str(k)
            kwargs1[k] = v
        return kwargs1

    def _invoke_method(self, func, args, kwargs, guard, callback=None):
        """
        Invokes a method under the context of a given guard
        """
        def task_callback(task):
            with guard():
                result = task.result()
                if callback:
                    callback(result)
        if getattr(func, '_jsonrpc_client', False):
            kwargs['client'] = self
        with guard():
            kwargs = self._fix_kwargs(kwargs)
            result = func(*args, **kwargs)
            if asyncio.iscoroutine(result):
                task = asyncio.async(result)
                task.add_done_callback(task_callback)
            elif callback:
                callback(result)

    def _invoke_callback_method(self, _id, func, args, kwargs, guard):
        """
        Invokes a method which will not return a result immediately, but will
        invoke a callback when the result is ready
        """
        def request_callback(result=None, error=None, **kwargs):
            """
            Add generic kwargs that are ignored so that jsonrpc responses can
            be passed straight through with callback(**response)
            """
            try:
                if None is not error:
                    response = self._errorresponse(_id, **error)
                else:
                    response = self._success_response(_id, result)
            except Exception as e:
                self._log.error('Error in request callback', exc_info=True)
                response = self._errorresponse(_id, -32603, 'internal error')
            outdata = json.dumps(response)
            self._async_send(outdata)
        kwargs['callback'] = request_callback
        self._invoke_method(func, args, kwargs, guard)

    def addmethod(self, method, func):
        self._methods[method] = func

    def getmethods(self):
        return self._methods
