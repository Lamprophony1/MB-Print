import asyncio

from . import detector_usb
from . import detector_mdns
from . import detector_reflector


class MakerBotDetector(object):
    """
    This class is a wrapper around the three detector classes to maintain
    backwards compatibility with Croissant.
    """
    def __init__(self, found_callback=None, thingiverse_token=None):
        self.lan_mdns_detector = detector_mdns.MakerBotDetector(found_callback=found_callback)

        self.usb_detector = detector_usb.MakerBotDetector.get_instance()
        self.usb_detector.start(found_callback)

        self.reflector_detector = None
        if (thingiverse_token is not None):
            self.reflector_detector = detector_reflector.MakerBotDetector.get_instance()
            self.reflector_detector.start_finding(thingiverse_token, found_callback)

    @asyncio.coroutine
    def shut_it_down(self):
        yield from self.lan_mdns_detector.shut_it_down()
        self.usb_detector.shut_it_down()
        if (self.reflector_detector is not None):
            self.reflector_detector.shut_it_down()
