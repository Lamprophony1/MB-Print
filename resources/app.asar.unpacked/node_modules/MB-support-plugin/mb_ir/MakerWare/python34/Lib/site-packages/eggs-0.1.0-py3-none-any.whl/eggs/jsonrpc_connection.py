import asyncio

from . import jsonrpc


class JsonRpcConnection(object):
    def __init__(self, ip, port):
        self._ip = ip
        self._port = port
        self._conn_future = asyncio.async(self._connect())
        self._jsonrpc = None

    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        if self._jsonrpc is not None:
            self._jsonrpc.close()

    @asyncio.coroutine
    def _connect(self, ssl_cxt=None):
        conn_coro = asyncio.open_connection(self._ip, self._port, ssl=ssl_cxt)
        self._jsonrpc = jsonrpc.JsonRpc(*(yield from conn_coro))

    @asyncio.coroutine
    def _request(self, method, params):
        yield from self._conn_future
        return (yield from self._jsonrpc.request(method, params))
