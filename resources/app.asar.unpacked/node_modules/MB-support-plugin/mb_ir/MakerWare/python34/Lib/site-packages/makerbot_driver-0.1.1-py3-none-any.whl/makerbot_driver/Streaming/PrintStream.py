import asyncio
import time
from . import utilities
from . import StreamingExceptions
import base64
import struct
import urllib.parse

class PrintStream(object):
	"""
	Base class for fetching data packets from the streaming server. Initialized
	with streaming server config and a file identifier. PrintStream fills the 
	instruction buffers and provides an iterator interface for subclasses to 
	complete.
	"""
	def __init__(self, streaming_config, file_id, access_token, printer_type):
		self.printer_type = printer_type
		self.access_token = access_token
		self.file_id = file_id

		streaming_url = urllib.parse.urlunsplit(
			(streaming_config["SCHEME"], # scheme
			 streaming_config["HOST"] + ":" + str(streaming_config["PORT"]), # host
			 "%s", # path, replaced below
			 "", "")) # empty

		self.status_path = streaming_url % streaming_config["STATUS"]
		self.init_path = streaming_url % streaming_config["INITIALIZATION"]
		self.stream_path = streaming_url % streaming_config["STREAM"]
		# buffers
		self.reading_buffer = ()
		self.filling_buffer = ()
		self.filling_buffer_lock = asyncio.Condition()
		self.current_packet_thread = None
	
		# stream state variables		
		self.index = 0
		self.packet_number = 0
		self.temp_token = None
		self._suspended = False
		self._finished = False
		
		post_params = {
			'printer' : self.printer_type,
			'access_token' : self.access_token, 
			'layout_id' : self.file_id, 
		}
		
		status_result = utilities.get_url_response(self.status_path, { 'access_token' : self.access_token, 'layout_id' : self.file_id })

		if status_result["print_in_progress"]:
			response = input("Proceeding will cancel any other prints.")
			if response == "y":
				post_params["start_token"] = status_result["start_token"]
			else:
				raise StreamingExceptions.PrintAlreadyActive

		initialization_result = utilities.post_url_response(self.init_path, post_params)
		self.temp_token = initialization_result['temp_token']
		self.print_length = initialization_result['print_length']
		
	def __getitem__(self, index):
		if index < len(self.reading_buffer):
			return self.reading_buffer[index]
		elif index - len(self.reading_buffer) < len(self.filling_buffer):
			return self.filling_buffer[index - len(self.reading_buffer)]
		elif self._finished:
			raise StopIteration
		else:
			raise StreamingExceptions.LatePacket

	def __getslice__(self, start, end):
		rb_len = len(self.reading_buffer)
		if end < rb_len:
			return self.reading_buffer[start:end]
		elif len(self.filling_buffer) >= (end - rb_len):
			return self.reading_buffer[start : rb_len] + self.filling_buffer[0 : end - rb_len]
		else:
			raise StreamingExceptions.LatePacket

	def find_next(self, element, start_index=0):
		index = self.reading_buffer.index(element, start_index)
		if index == -1:
			index = self.filling_buffer.index(element, 0)
		return index

	def get_next_packet(self):
		post_params = {
			'access_token' : self.access_token, 
			'packet_no' : self.packet_number,
			'layout_id' : self.file_id, 
			'temp_token' : self.temp_token 
		}

		stream_info = utilities.post_url_response(self.stream_path, post_params, retries=5)
		self.temp_token = stream_info['temp_token']		
		if len(stream_info['packet']) == 0:
			self._finished = True
		else:
			self.packet_number += 1
			decoded = base64.b64decode(stream_info['packet'])
			unpacked_buffer = struct.unpack("<%sB" % len(decoded), decoded)
			self.filling_buffer_lock.acquire()
			self.filling_buffer = unpacked_buffer
			self.filling_buffer_lock.release()

	# File-like interface
	def __enter__(self):
		return self

	def __exit__(self, type, value, traceback):
		### no-op: just to satisfy the file interface
		pass
		
	### Iterator interface
	def __iter__(self):
		return self

	def __next__(self):
		# FIXME -- put this back in when we're ready to pause
		#if self._suspended:
		#	time.sleep(1)
		#	if not self.current_packet_thread.isAlive():
		#		return self.resume()
				
		try:
			return self.parse_command()
		except StreamingExceptions.LatePacket:
			#return self.next() if self._suspended else self.suspend()
			raise

	def resume(self):
		"""
		Implemented by subclasses
		"""
		self._suspended = False

	def suspend(self):
		"""
		Implemented by subclasses
		"""
		self._suspended = True

	def parse_command(self):
		"""
		To be implemented by subclasses.
		"""
		raise NotImplementedError


