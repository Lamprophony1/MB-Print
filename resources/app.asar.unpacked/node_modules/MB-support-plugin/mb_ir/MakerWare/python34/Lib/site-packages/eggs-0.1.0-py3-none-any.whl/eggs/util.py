
def type_to_bot_type(reflector_type):
    try:
        return {
            "platypus": "replicator_5",
            "moose": "z18_6",
            "wildduck": "mini_8",
            "horseshoe": "replicator_b",
        }[reflector_type]
    except KeyError:
        raise Exception("Invalid printer type: ", reflector_type)


def pid_from_bot_type(bot_type):
    # bot_type is {public name}_{pid}
    return int(bot_type[-1], 16)


def bot_type_from_pid(pid):
    if pid == 5:
        return "replicator_5"
    elif pid == 6:
        return "z18_6"
    elif pid == 8:
        return "mini_8"
    elif pid == 11:
        return "replicator_b"
    elif pid == 14:
        return "fire_e"
    elif pid == 15:
        return "lava_f"
    else:
        raise Exception("Invalid pid: ", pid)
