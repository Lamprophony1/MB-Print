class BaseException(Exception):
	def __repr__(self):
		return repr(self.args)
	def __str__(self):
		return repr(self.args)

class UnknownCommandError(BaseException):
	pass

class WrongPayloadLengthError(BaseException):
	pass

class LatePacket(BaseException):
	pass

class PrintAlreadyActive(BaseException):
	pass