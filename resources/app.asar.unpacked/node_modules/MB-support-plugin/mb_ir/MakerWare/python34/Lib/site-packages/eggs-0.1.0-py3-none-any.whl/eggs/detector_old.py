import asyncio
import datetime
import json
import netifaces
import random
import socket
import sys
import time


class ListenerProtocol(asyncio.Protocol):
    def __init__(self, detector):
        self.detector = detector

    def datagram_received(self, data, addr):
        data = data.decode()
        try:
            self.detector.discovered_bot(json.loads(data))
        except Exception as e:
            print("Error: received invalid data from bot reply: %s" % e)

# I don't want clients to be sending out discovery broadcasts indefinitely,
# but I don't trust clients to actually close the detector quickly, nor
# should they necessarily have to.  I also want all currently online bots
# to show up quickly we create a detector object, but a single broadcast
# will not necessarily get every bot to show up.  But we don't want to
# overwhelm the bots with a ton of discovery packets.
#
# The following list of delays determine how many broadcasts we send and
# with what timing.  Each number indicates how long in seconds after the
# last broadcast to wait before sending another broadcast -- we send one
# broadcast immediately and then one broadcast for each list element.
BROADCAST_PROFILE = [0.5, 1.5]


class Broadcaster(object):
    """
    Broadcasts discovery packets on a single interface.
    """
    def __init__(self, bcast_ip):
        broadcast_dict = {"command": "broadcast"}
        self._broadcast_message = json.dumps(broadcast_dict).encode("UTF-8")
        self._broadcast_port = 12307
        self._bcast_ip = bcast_ip

        try:
            self._socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self._socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            self._socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        except OSError:
            raise Exception("Error setting up broadcaster socket. "
                            "Stop conveyor if it's running.")

    @asyncio.coroutine
    def run(self):
        for delay in BROADCAST_PROFILE + [0]:
            try:
                self._socket.sendto(self._broadcast_message,
                                    (self._bcast_ip, self._broadcast_port))
            except OSError as e:
                print("Error broadcasting on %s: %s" % (self._bcast_ip, e))
                break
            yield from asyncio.sleep(delay)

    def stop(self):
        self._socket.close()


class MakerBotDetector(object):
    def __init__(self, found_callback=None):
        self._found_callback = found_callback
        self.foundBots = {}
        self.tasks = []
        self.broadcasters = []

        endpoint = asyncio.get_event_loop().create_datagram_endpoint(
            lambda: ListenerProtocol(self),
            local_addr=('0.0.0.0', 12308), family=socket.AF_INET,
            flags = (socket.SOL_SOCKET | socket.SO_BROADCAST))
        self.endpoint_task = asyncio.async(endpoint)

        bcast_ips = get_bcast_ips()
        for broadcaster in [Broadcaster(ip) for ip in bcast_ips]:
            self.broadcasters.append(broadcaster)
            self.tasks.append(asyncio.async(broadcaster.run()))

    def discovered_bot(self, data):
        addr = ":".join(["tcp", data['ip'], str(data['port'])])
        data["connection_type"] = "network"
        if addr not in self.foundBots:
            data['address'] = addr
            # Replace the iserial field with the canonical VID:PID:iserial
            # that we use as a unique identifier.
            data['uid'] = '{vid:04x}:{pid:04x}:{iserial}'.format(**data)
            del data['iserial']

            if self._found_callback:
                self._found_callback(data)
            self.foundBots[data['address']] = data

    def shut_it_down(self):
        for broadcaster in self.broadcasters:
            broadcaster.stop()

        for task in self.tasks:
            task.cancel()
        # close the transport if one was successfully created
        if (not self.endpoint_task.cancel() and
                not self.endpoint_task.cancelled()):
            transport = self.endpoint_task.result()[0]
            transport.close()


def get_bcast_ips():
    bcast_ips = []
    for iface in netifaces.interfaces():
        # Only retrieve IPv4 interfaces
        ifaddrs = netifaces.ifaddresses(iface).get(netifaces.AF_INET, [])
        for ifaddr in ifaddrs:
            bcast_ip = ifaddr.get('broadcast')
            # Filter out ip addresses that can't broadcast (loopback),
            # or have a weird setup.
            if bcast_ip and bcast_ip != ifaddr.get('addr'):
                bcast_ips.append(bcast_ip)
    return bcast_ips
