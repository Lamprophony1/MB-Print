import urllib.request, urllib.parse, urllib.error
import json
import time
import urllib.request, urllib.error, urllib.parse

NO_RETRY_CODES = (401,)

def get_url_response(url, get_params, retries=0):
	tries = -1
	full_url = '?'.join((url, urllib.parse.urlencode(get_params)))
	response_body = None
	while response_body is None:# and tries < retries:
		tries += 1
		try:
			response = urllib.request.urlopen(full_url)
			response_body = json.loads(response.read())
		except urllib.error.HTTPError as e:
			if tries < retries and e.code not in NO_RETRY_CODES:
				time.sleep(1)
				continue
			else:
				raise e

	return response_body


def post_url_response(url, get_params, retries=0):
	tries = -1
	data = urllib.parse.urlencode(get_params)
	response_body = None
	while response_body is None and tries < retries:
		tries += 1
		try:
			response = urllib.request.urlopen(url, data)
			response_body = json.loads(response.read())
		except urllib.error.HTTPError as e:
			if tries < retries and e.code not in NO_RETRY_CODES:
				time.sleep(1)
				continue
			else:
				raise e

	return response_body
