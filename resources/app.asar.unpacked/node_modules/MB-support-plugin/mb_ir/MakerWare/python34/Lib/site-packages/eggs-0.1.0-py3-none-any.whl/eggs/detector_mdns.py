import asyncio
import ipaddress
import zeroconf


mdns_service = "_makerbot-jsonrpc._tcp.local."


class MakerBotDetector(object):
    def __init__(self, found_callback=None):
        self._found_callback = found_callback
        self.foundBots = {}
        self.zeroconf = zeroconf.Zeroconf()
        self.browser = zeroconf.ServiceBrowser(
            self.zeroconf, mdns_service, self)
        self.loop = asyncio.get_event_loop()
        self._done = False

    def remove_service(self, zeroconf, type, name):
        if name in self.foundBots:
            fut = self.foundBots[name]
            if not fut.done():
                fut.cancel()
            del self.foundBots[name]

    def add_service(self, zeroconf, type, name):
        def call_get_service_info(zeroconf, type, name):
            try:
                return zeroconf.get_service_info(type, name)
            except OSError:
                if not self._done:
                    # "OSError: [Errno 9] Bad file descriptor" will get thrown
                    # if zeroconf gets closed before get_service_info completes
                    raise

        # ignore any more incoming add_service calls if they happen after we ask
        # to stop detecting
        if not self._done:
            fut = self.loop.run_in_executor(None, call_get_service_info, zeroconf, type, name)
            fut.add_done_callback(self.handle_info)
            self.foundBots[name] = fut

    def handle_info(self, future):
        try:
            info = future.result()
            if info is None:
                # happens when zeroconf is unable ot retrieve info for a service
                # nothing to do then
                return

            data = {}
            for key, value in info.properties.items():
                data[str(key, encoding="utf-8")] = str(value, encoding="utf-8")
    
            if data['pid'] is '4':
                # do not handle tinkerbell mini_4
                return

            data["connection_type"] = "network"
            data['ip'] = str(ipaddress.IPv4Address(info.address))
            data['vid'] = int(data['vid'])
            data['pid'] = int(data['pid'])
            addr = ":".join(["tcp", data['ip'], str(data['port'])])

            data['address'] = addr
            # Replace the iserial field with the canonical VID:PID:iserial
            # that we use as a unique identifier.
            data['uid'] = '{vid:04x}:{pid:04x}:{iserial}'.format(**data)
            del data['iserial']

            if self._found_callback: self._found_callback(data)
        except asyncio.CancelledError:
            # cancelled before we finished getting info
            pass

    @asyncio.coroutine
    def shut_it_down(self):
        self._done = True
        unfinished_futures = [f for f in self.foundBots.values() if not f.done()]
        if not len(unfinished_futures) == 0:
            # arbitrary timeout just in case
            done, pending = yield from asyncio.wait(unfinished_futures, loop=self.loop, timeout=100)
            for fut in pending:
                fut.cancel()

        self.zeroconf.close()
