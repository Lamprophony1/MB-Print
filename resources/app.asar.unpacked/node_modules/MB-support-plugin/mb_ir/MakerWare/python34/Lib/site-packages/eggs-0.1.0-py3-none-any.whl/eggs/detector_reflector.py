import json
import asyncio
import aiohttp
import ssl
import datetime

from . import reflector
from . import util

class MakerBotDetector(object):
    _instance = None

    @staticmethod
    def get_instance():
        if MakerBotDetector._instance is None:
            MakerBotDetector._instance = MakerBotDetector()
        return MakerBotDetector._instance

    def __init__(self):
        self._last_searched = None

        self._tasks = []
        self._foundPrinters = []

    def start_finding(self, thingiverse_token, found_callback):
        if self._should_search_again():
            self._last_searched = datetime.datetime.now()
            self._foundPrinters = []
            self._tasks.append(
                asyncio.async(self._find_reflector_bots(
                    thingiverse_token, found_callback)))
        else:
            for printer in self._foundPrinters:
                found_callback(printer)

    def _should_search_again(self):
        if self._last_searched is None:
            return True
        else:
            now = datetime.datetime.now()
            # lets not spam the reflector server so much...
            return (now - self._last_searched).total_seconds() > 30

    def _callback_info_for_legacy(self, iserial, data):
        data["bot_type"] = util.type_to_bot_type(data["type"])
        del data["type"]
        data["vid"] = 9153
        data["pid"] = util.pid_from_bot_type(data["bot_type"])
        data["uid"] = '{:04x}:{:04x}:{}'.format(
            data["vid"], data["pid"], iserial)
        data["ip"] = ""
        data["address"] = ""
        data["machine_name"] = data["name"]
        del data["name"]
        data["connection_type"] = "reflector"

        return data

    def _get_callback_info(self, iserial, data):
        status = data['status']
        status["vid"] = 9153
        status["pid"] = util.pid_from_bot_type(status["bot_type"])
        status["uid"] = '{:04x}:{:04x}:{}'.format(
            status["vid"], status["pid"], iserial)
        status["address"] = ""
        status["connection_type"] = "reflector"

        return status

    @asyncio.coroutine
    def _find_reflector_bots(
            self, thingiverse_token, found_callback, ssl_context=None):
        response = yield from reflector.get_reflector_bots(
            thingiverse_token, ssl_context)

        for iserial in response.keys():
            data = response[iserial]

            # form an acceptable dict for the callback
            try:
                if 'status' in data and 'bot_type' in data['status']:
                    data = self._get_callback_info(iserial, data)
                else:
                    data = self._callback_info_for_legacy(iserial, data)

                self._foundPrinters.append(data)
                found_callback(data)
            except Exception as e:
                pass

    def shut_it_down(self):
        for task in self._tasks:
            if not task.done():
                task.cancel()
        self._tasks = []
