import json
import asyncio
import aiohttp
import ssl

CONSTANTS = {
    "API_URL": 'https://reflector.makerbot.com',
}


def _get_header(thingiverse_token):
    return {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + thingiverse_token
    }


def _do_get(url, headers, ssl_context=None):
    conn = aiohttp.TCPConnector(ssl_context=ssl_context)
    response = yield from aiohttp.request(
        'GET', url, headers=headers, connector=conn)
    # Must read before closing the connection
    output = yield from response.read()
    conn.close()
    return output


def _do_post(url, headers, data, ssl_context=None):
    conn = aiohttp.TCPConnector(ssl_context=ssl_context)
    response = yield from aiohttp.request(
        'POST', url, headers=headers, data=json.dumps(data), connector=conn)
    output = yield from response.read()
    return output


@asyncio.coroutine
def get_printer_state(thingiverse_token, printer_id, ssl_context=None):
    response = yield from _do_get(
        CONSTANTS["API_URL"] + '/printers/' + printer_id,
        _get_header(thingiverse_token),
        ssl_context)
    return json.loads(response.decode("utf-8"))["printers"]


@asyncio.coroutine
def get_reflector_bots(thingiverse_token, ssl_context=None):
    try:
        response = yield from _do_get(
            CONSTANTS["API_URL"] + '/printers',
            _get_header(thingiverse_token),
            ssl_context)
        return json.loads(response.decode("utf-8"))["printers"]
    except aiohttp.errors.ClientOSError:
        # network down; it happens sometimes
        return {}


@asyncio.coroutine
def do_reflector_call(thingiverse_token, printer_iserial, ssl_context=None):
    response = yield from _do_post(
        CONSTANTS["API_URL"] + '/call',
        _get_header(thingiverse_token),
        {"printer_id": printer_iserial},
        ssl_context)

    response = json.loads(response.decode("utf-8"))["call"]
    output = {
        "call_id": response["id"],
        "relay": response["relay"],
        "client_code": response["client_code"],
        "thingiverse_token": thingiverse_token,
        "printer_id": printer_iserial
    }
    return output
