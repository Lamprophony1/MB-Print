import json
import logging
import time
from . import utilities
import makerbot_driver

class X3GState(object):
	def __init__(self):
		self._log = logging.getLogger(self.__class__.__name__)
		self.profile = None
		self.values = {}
		self.wait_for_ready_packet_delay = 100  # ms
		self.wait_for_ready_timeout = 600  # seconds
		self.percentage = 0

	def set_build_percentage(self, build_percentage):
		"""Sets the build percentage to a certain percentage.
		"""

		if not (0 <= build_percentage <= 100):
			raise makerbot_driver.Gcode.BadPercentageError

		self.percentage = build_percentage

	def set_build_name(self, build_name):
		if not isinstance(build_name, str):
			raise TypeError
		else:
			self.values['build_name'] = build_name

class X3GParser(object):
	def __init__(self):
		### Parser interface stuff
		self.state = X3GState()
		self.s3g = None
		self.line_number = 1
		self._log = logging.getLogger(self.__class__.__name__)
		### End parser interface stuff

	def execute_line(self, line):
		### FIXME -- could put all commands functions into a dict indexed by
		### the command number. Keep it in mind (see ../Gdode/Parser.py)
		command_byte = line[0]
		if command_byte == 150:
			### Just update the state, since we're sending the payload
			### normally
			self.state.set_build_percentage(line[1])
		self.s3g.writer.send_command(line)



