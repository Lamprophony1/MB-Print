import asyncio
import os
import re
import platform

import watchdog.observers
from watchdog.events import RegexMatchingEventHandler
import appdirs

from . import util
from . import jsonrpc_connection

CONSTANTS = {
    "USB_SERVER_DIR": {
        "win": "\\\\.\\pipe\\",
        "other": "/tmp/mb_printers/",
    },
    "MBP_PREFIX": "mbp",
    "APP_NAME": "makerbot-desktop",
    "APP_AUTHOR": "Makerbot",
}


def bot_info_from_filename(usb_pipe):
    prefix, vid, pid, iserial, port_num = usb_pipe.split("-")
    return {
        "vid": int(vid),
        "pid": int(pid),
        "iserial": str(iserial),
        "ip": "127.0.0.1",
        "port": int(port_num),
        "bot_type": util.bot_type_from_pid(int(pid)),
        "connection_type": "usb",
    }


class USBAddedHandler(RegexMatchingEventHandler):
    def on_created(self, event):
        if event.is_directory:
            usb_pipe = os.path.basename(event.src_path)
            if self.added_callback:
                self.added_callback(bot_info_from_filename(usb_pipe))

    def on_deleted(self, event):
        if event.is_directory:
            usb_pipe = os.path.basename(event.src_path)
            if self.removed_callback:
                self.removed_callback(bot_info_from_filename(usb_pipe))


class Handshaker(jsonrpc_connection.JsonRpcConnection):
    def __init__(self, ip, port):
        super(Handshaker, self).__init__(ip, port)

    @asyncio.coroutine
    def handshake(self):
        return (yield from self._request('handshake', {}))


class MakerBotDetector(object):
    _instance = None

    @staticmethod
    def get_instance():
        if MakerBotDetector._instance is None:
            MakerBotDetector._instance = MakerBotDetector()
        return MakerBotDetector._instance

    def __init__(self):
        self._found_callback = None
        self._removed_callback = None

        self._usb_pipe_regex = ".*mbd.*"
        self.observer = None
        self.found_bots = {}
        self._tasks = []

        self._loop = asyncio.get_event_loop()

        self.set_os_usb_location()

    def set_os_usb_location(self):
        """
        Set self.os_usb_location and make sure it exists.

        This is broken out from the rest of this functionality of this
        class during unit tests so that it can be verified independently.
        """
        if platform.system() == "Windows":
            self.os_usb_location = appdirs.user_data_dir(
                CONSTANTS["APP_NAME"], CONSTANTS["APP_AUTHOR"])
        else:
            self.os_usb_location = "/tmp/makerbot-usb-daemon"

        try:
            os.makedirs(self.os_usb_location)
        except FileExistsError:
            # if it already exists, leave it
            pass
        else:
            # we created it; make sure it has the right permissions
            os.chmod(self.os_usb_location, 0o777)

    def _found_callback_internal(self, data):
        def handle_task_finish(fut):
            try:
                # raise the err or else it will get swallowed...
                err = fut.exception()
                if err:
                    raise err
            except asyncio.CancelledError:
                pass
            else:
                return fut.result()

        task = asyncio.async(self._get_found_task(data), loop=self._loop)
        task.add_done_callback(handle_task_finish)
        self._tasks.append(task)

    @asyncio.coroutine
    def _get_found_task(self, data):
        data['uid'] = '{vid:04x}:{pid:04x}:{iserial}'.format(**data)
        addr = ":".join(["tcp", data['ip'], str(data['port'])])
        data['address'] = addr

        if addr not in self.found_bots:
            with Handshaker(data['ip'], data['port']) as handshaker:
                res = yield from handshaker.handshake()

                data.update(res)
                self.found_bots[data['address']] = data

        # Replace the iserial field with the canonical VID:PID:iserial
        # that we use as a unique identifier.
        del data['iserial']

        if self._found_callback:
            self._found_callback(data)

    def _removed_callback_internal(self, data):
        try:
            addr = ":".join(["tcp", data['ip'], str(data['port'])])
            del self.found_bots[addr]
        except KeyError:
            pass
        if self._removed_callback:
            self._removed_callback(data)

    def start(self, found_callback=None, removed_callback=None):
        self._found_callback = found_callback
        self._removed_callback = removed_callback

        # Check if any bots are already connected
        already_present = os.listdir(self.os_usb_location)
        for usb_pipe in [f for f in already_present if re.search(self._usb_pipe_regex, f) is not None]:
            bot_info = bot_info_from_filename(usb_pipe)
            self._found_callback_internal(bot_info)

        self.observer = watchdog.observers.Observer()
        self.usb_added_handler = USBAddedHandler(
            regexes=[self._usb_pipe_regex])
        self.usb_added_handler.added_callback = self._found_callback_internal
        self.usb_added_handler.removed_callback = self._removed_callback_internal

        self.observer.schedule(
            self.usb_added_handler, self.os_usb_location, recursive=False)
        self.observer.start()

    def shut_it_down(self):
        for task in self._tasks:
            if not task.done():
                task.cancel()

        if self.observer:
            self.observer.stop()
