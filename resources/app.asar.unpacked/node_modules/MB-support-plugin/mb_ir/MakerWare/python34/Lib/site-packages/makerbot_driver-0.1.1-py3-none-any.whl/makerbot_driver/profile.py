"""
A machine profile object that holds all values for a specific profile.
"""

import json
import os
import re
import logging
import zipfile

wheel_profile_path = 'makerbot_driver/profiles/'
profile_extension = '.json'

def _get_wheel_path():
    this_file = os.path.abspath(os.path.dirname(__file__))
    this_wheel = os.path.abspath(os.path.join(this_file, '..'))
    return this_wheel


class Profile(object):
    def __init__(self, name):
        """Constructor for the profile object.
        @param string name: Name of the profile, NOT the path.
        """
        self._log = logging.getLogger(self.__class__.__name__)
        self.name = os.path.splitext(name)[0] # name without any extension
        
        if not name.endswith(profile_extension):
            name += profile_extension
        
        # Hack: look for our profiles inside the zipped wheel file
        with zipfile.ZipFile(_get_wheel_path(), 'r') as archive:
            
            path = os.path.join(wheel_profile_path, name)
            self._log.debug('{"event":"open_profile", "path":%s}', path)

            if path in archive.namelist():    
                try:
                    data = archive.read(path)
                    self.values = json.loads(str(data, encoding="utf-8"))
                except Exception as e:
                    self._log.debug('profile load fail for %s on err %s',
                                    os.path.abspath(path), str(e))
                    raise e
            else:
                self._log.debug("no such profile file %s for %s", path, name)
                raise IOError("no such profile file %s for %s", path, name)


def list_profiles():
    """
    Looks in the ./profiles directory for all files that
    end in .json and returns that list.
    @return A generator of profiles without their .json extensions
    """
    # Hack: look for our profiles inside the zipped wheel file
    with zipfile.ZipFile(_get_wheel_path(), 'r') as archive:
        
        # Get all files in the profile path (just the basenames)
        possible_files = [pfile for pfile in archive.namelist() if wheel_profile_path in pfile]
        possible_files = [os.path.basename(pfile) for pfile in possible_files]

        for f in possible_files:
            root, ext = os.path.splitext(f)
            if profile_extension == ext :
                yield root

def search_profiles_with_regex(regex):
    """
    Looks in profiledir for any profiles matching the regex
    """
    # Hack: look for our profiles inside the zipped wheel file
    with zipfile.ZipFile(_get_wheel_path(), 'r') as archive:

        # Get all files in the profile path (just the basenames)
        possible_files = [pfile for pfile in archive.namelist() if wheel_profile_path in pfile]
        possible_files = [os.path.basename(pfile) for pfile in possible_files]

        matches = []
        if regex is not None:
            for f in possible_files:
                match = re.search(regex, f)
                root, ext = os.path.splitext(f)
                if match and ext == profile_extension:
                    matches.append(match.group())
        return matches
